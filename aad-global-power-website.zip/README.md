# AAD Global Power, Inc. Website

A responsive static website for AAD Global Power, Inc.

## Files
- `index.html` — website structure
- `styles.css` — design and responsive layout
- `script.js` — navigation, battery finder, and quote-request interactions

## Run locally
Open `index.html` in a browser.

## Publish with GitHub Pages
1. Create a GitHub repository named `aad-global-power-website`.
2. Upload `index.html`, `styles.css`, `script.js`, and `README.md`.
3. In GitHub, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`.
6. Save. GitHub will provide the public Pages address.

## Important
The battery finder is a front-end demo. It does not contain a live catalog or guaranteed vehicle fitment database. Connect it to your actual inventory/fitment data before using it to make purchase decisions.

The quote form uses the visitor's email app via `mailto:`. For production use, connect it to a real form/email service.
