const menuToggle=document.querySelector(".menu-toggle"),nav=document.querySelector(".nav");
menuToggle?.addEventListener("click",()=>nav.classList.toggle("open"));
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const finderForm=document.getElementById("finderForm"), result=document.getElementById("finderResult");
finderForm.addEventListener("submit",(e)=>{
  e.preventDefault();
  const type=document.getElementById("vehicleType").value;
  const year=document.getElementById("year").value;
  const make=document.getElementById("make").value;
  const model=document.getElementById("model").value;
  const engine=document.getElementById("engine").value;
  const label={Car:"automotive",Truck:"truck / heavy-duty","Boat / Marine":"marine",Commercial:"commercial"}[type]||"battery";
  result.hidden=false;
  result.innerHTML=`<strong>Battery request created.</strong><br>We’re looking for a ${label} battery${make?` for your ${year||""} ${make} ${model||""}`:""}${engine?` (${engine})`:""}. <a href="#contact">Send these details for a quote →</a>`;
  result.scrollIntoView({behavior:"smooth",block:"nearest"});
  document.getElementById("details").value=[year,make,model,engine].filter(Boolean).join(" ");
});

document.getElementById("quoteForm").addEventListener("submit",(e)=>{
  e.preventDefault();
  const name=document.getElementById("name").value.trim();
  const phone=document.getElementById("phone").value.trim();
  const email=document.getElementById("email").value.trim();
  const need=document.getElementById("need").value;
  const details=document.getElementById("details").value.trim();
  const body=`Hello AAD Global Power,%0D%0A%0D%0AI'd like a quote.%0D%0AName: ${encodeURIComponent(name)}%0D%0APhone: ${encodeURIComponent(phone)}%0D%0AEmail: ${encodeURIComponent(email)}%0D%0ANeed: ${encodeURIComponent(need)}%0D%0ADetails: ${encodeURIComponent(details)}`;
  document.getElementById("formMessage").innerHTML=`Your request is ready. <a href="mailto:?subject=AAD Global Power Quote Request&body=${body}">Open your email app to send it.</a> For immediate help, call <a href="tel:+13054015198">(305) 401-5198</a>.`;
});
document.getElementById("yearNow").textContent=new Date().getFullYear();
